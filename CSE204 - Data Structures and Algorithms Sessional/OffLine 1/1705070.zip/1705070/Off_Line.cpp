#include <bits/stdc++.h>
#include <chrono>

#define ll long long
#define  F0R(i, a) for(int i=0;i<(a);++i)
#define  sync ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define all(v) v.begin(),v.end()
#define exs EXIT_SUCCESS

using namespace std;

const auto longPrime = 1000000009;
mt19937 mrand(random_device{}());

auto rnd(int x) { return mrand() * mrand() % x; }

vector<ll> vectorOfRandomInteger;
bool loop = true;
ofstream basicOfstream("Offline-1-ComparingTwoAlgorithm'sTimeComplexity.out");

void LinearSearch(ll keyToFind) {

    string s1 = to_string(keyToFind);
    F0R(i, vectorOfRandomInteger.size()) {
        string s2 = to_string(vectorOfRandomInteger[i]);
        if (vectorOfRandomInteger[i] == keyToFind) {
            return;
        }
    }
    return;
}

void BinarySearch(ll keyToFind) {

    string s1 = to_string(keyToFind);
    ll first_iteration = 0, final_iteration = vectorOfRandomInteger.size() - 1;
    ll middle_iteration;

    while (first_iteration <= final_iteration) {

        middle_iteration = (final_iteration - first_iteration) / 2 + first_iteration;
        string s2 = to_string(vectorOfRandomInteger[middle_iteration]);

        if (s1.compare(s2) == 0) {
            return;
        } else if (vectorOfRandomInteger[middle_iteration] < keyToFind) {
            first_iteration = middle_iteration + 1;
        } else {
            final_iteration = middle_iteration - 1;
        }
    }
    return;
}

void SearchForEachTime(long n) {

    auto lapsTimeLinearSearch = 0.0, lapsTimeBinarySearch = 0.0;
    F0R(i, 10000) {

        ll randomNumber = rnd(longPrime) * rnd(longPrime) + rnd(10);

        auto start = std::chrono::steady_clock::now();
        LinearSearch(randomNumber);
        auto stop = std::chrono::steady_clock::now();
        lapsTimeLinearSearch += std::chrono::duration_cast<std::chrono::nanoseconds>(stop - start).count();

        auto start1 = std::chrono::steady_clock::now();
        BinarySearch(randomNumber);
        auto stop1 = std::chrono::steady_clock::now();
        lapsTimeBinarySearch += std::chrono::duration_cast<std::chrono::nanoseconds>(stop1 - start1).count();
    }
    basicOfstream << vectorOfRandomInteger.size() << (double) lapsTimeLinearSearch / (10000) << '\t'
                  << (double) lapsTimeBinarySearch / (10000)
                  << endl;
    cout << (double) lapsTimeLinearSearch / (10000) << '\t' << (double) lapsTimeBinarySearch / (10000)
         << endl;
}

void ArrayGenerator(ll n) {

    vectorOfRandomInteger.clear();

    auto first_number = rnd(longPrime) * rnd(longPrime) + rnd(10);
    auto second_number = rnd(longPrime) * rnd(longPrime) + rnd(10);

    if (first_number > second_number) {
        second_number = 2 * first_number;
    }

    F0R(i, n) {
        auto x = (rnd(longPrime) * rnd(longPrime)) % (second_number - first_number) + first_number;
        vectorOfRandomInteger.push_back(x);
    }

    sort(all(vectorOfRandomInteger));
    SearchForEachTime(n);
}

int main() {
    sync

    int k[] = {10, 100, 500, 1000, 5000, 10000,20000, 50000, 100000};

    for (int i = 0; k[i]; i++) {
        ArrayGenerator(k[i]);
    }

    return exs;
}

