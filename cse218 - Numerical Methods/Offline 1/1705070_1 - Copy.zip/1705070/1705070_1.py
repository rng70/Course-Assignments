# Creator _Sabyasachi


import numpy
from matplotlib import pyplot
import array


def taylor(m, n):
    is_plus = True
    count = 1
    total_sum = 0.0
    while True:
        if count > n:
            return total_sum
        elif is_plus:
            total_sum += pow(m, count) / count
            count += 1
            is_plus = False
        else:
            total_sum -= pow(m, count) / count
            count += 1
            is_plus = True


def graph(k):
    y = numpy.log(k)
    pyplot.interactive(False)
    pyplot.plot(k, y, label='ln(x)')
    pyplot.xlabel("Step size")
    pyplot.ylabel("Value of ln(x)")
    pyplot.title("1(b) - Value of ln(x) using built in function")
    pyplot.legend(loc="best")
    pyplot.grid()
    pyplot.show()


def error_graph(k, l):
    pyplot.figure()
    pyplot.interactive(False)
    pyplot.plot(k, l, label='Relative appx. error')
    pyplot.title("1(d) - Relative approximation error")
    pyplot.ylabel("Error relative to each iteration")
    pyplot.xlabel("Number of Terms")
    pyplot.legend(loc="best")
    pyplot.grid()
    pyplot.show()


def first_part():
    x = float(input("Enter the value of x in range of −1<x≤1 : "))

    if x <= 0:
        print("This will cause an error as negative value of log is not defined")
        exit(-1)
    number_of_terms = int(input("Enter the number of terms of Taylor series to count : "))

    print("The actual value of ln(1+x) is ", numpy.log(1 + x))
    print("The approximate value of ln(1+x) using Taylor series is ", taylor(x, number_of_terms))


def second_part():
    step_range = numpy.arange(-.99, 1.1, 0.1)
    graph(1 + step_range)


def third_part():
    need = [1, 3, 5, 20, 50]
    list_of_array = []
    step_range = numpy.arange(-.99, 1.1, 0.1)
    for i in need:
        arr = array.array('d')
        for j in step_range:
            arr.append(taylor(j, i))
        list_of_array.append(arr)

    y = numpy.log(1 + step_range)
    pyplot.plot(step_range, y, label="Built in function")
    pyplot.plot(step_range, list_of_array[0], label="Iteration  : 1")
    pyplot.plot(step_range, list_of_array[1], label="Iteration  : 3")
    pyplot.plot(step_range, list_of_array[2], label="Iteration  : 5")
    pyplot.plot(step_range, list_of_array[3], label="Iteration  : 20")
    pyplot.plot(step_range, list_of_array[4], label="Iteration  : 50")
    pyplot.xlabel("Value of x")
    pyplot.ylabel("Value of ln(1+x)")
    pyplot.title("1(b)-1(c) Graph of ln(1+x) using Taylor series and Built in ln(x) function")
    pyplot.legend(loc="best")
    pyplot.grid()
    pyplot.show()


def fourth_part():
    relative_error = array.array('d')
    in_range = range(2, 51)
    previous_value = taylor(.5, 1)
    i = 2
    while i <= 50:
        value = taylor(.5, i)
        relative_error.append(numpy.abs(value - previous_value) * 100 / value)
        previous_value = value
        i += 1

    error_graph(in_range, relative_error)


first_part()
second_part()
third_part()
fourth_part()
